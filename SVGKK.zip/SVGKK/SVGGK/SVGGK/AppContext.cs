﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Entity;

namespace SVGGK.Classes
{
    class AppContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public AppContext() : base("DefaultConnection") { }
    }
}

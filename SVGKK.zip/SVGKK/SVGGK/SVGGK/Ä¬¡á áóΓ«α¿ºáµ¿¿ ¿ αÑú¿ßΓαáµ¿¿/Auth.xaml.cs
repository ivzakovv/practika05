﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SVGGK
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Window
    {

        ApplicationContext db;

        public Auth()
        {
            InitializeComponent();

            db = new ApplicationContext();
        }

        private void Btn_Auth_Click(object sender, RoutedEventArgs e)
        {
            private void Button_Reg_Click(object sender, RoutedEventArgs e)
            {
                string loginl = textBox_Login.Text.Trim();
                string passl = pass_Box.Text.Trim();


                MessageBox.Show("Все хорошо!");
                User user = new User(login, email, pass);

                db.Users.Add(user);
                db.SaveChanges();

                Auth oauth = new Auth();
                oauth.Show();
                this.Hide();
            }
            }
        }
    }
}
